package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtil {
	private static final String DRIVER="oracle.jdbc.OracleDriver";
	private static final String URL="jdbc:oracle:thin://127.0.0.1:1521:orcl";
	private static final String USERNAME="goshopping";
	private static final String PWD="goshopping";
	
	static{
		try {
			Class.forName(DRIVER);			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * 返回连接对象的方法
	 */
	public static Connection getConnection(){
		Connection con=null;
		try {
			con=DriverManager.getConnection(URL, USERNAME, PWD);						
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;	
	}
	
	/*
	 * 关闭所有对象
	 */
	public static void closeAll(Connection con,Statement st,ResultSet rs){
		try {
			if(rs!=null){
				rs.close();
			}
					
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(st!=null){
			try {
				st.close();
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
		if(con!=null){
			try {
				con.close();
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
		
	}
	

}
