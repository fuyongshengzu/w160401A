package dao;

import java.sql.Connection;



import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBUtil;

import bean.Customer;
import bean.Orders;

import bean.ShipmentsInfo;

public class OrderDao {
	

	/*
	 * 发货
	 * 1.向发货信息表添加数据
	 * 2.修改orders的Order_state和Order_save
	 */		
	public boolean insertShipmentsInfo(ShipmentsInfo sp){
	boolean flag=false;
	boolean flag1=false;
	boolean flag2=false;
	Connection conn=null;
	PreparedStatement pst=null;
	String sql="insert into ShipmentsInfo(order_id,p_id,Order_adress,express,username) values(?,?,?,?,?)";
	String sq2="update orders set order_state=?,order_save=? where order_id=?";
	try {
		conn=DBUtil.getConnection();
		pst=conn.prepareStatement(sql);
		pst.setInt(1, sp.getOrder_id());
		pst.setInt(2, sp.getP_id());
		pst.setString(3, sp.getOrder_adress());
		pst.setString(4, sp.getExpress());
		pst.setString(5, sp.getUsername());
		int rows=pst.executeUpdate();
		if(rows>0){
			flag1=true;			
		}	
		
		pst=conn.prepareStatement(sq2);
		pst.setString(1, "发货");
		pst.setString(2, "保存");
		pst.setInt(3, sp.getOrder_id());
		int rows1=pst.executeUpdate();
		if(rows1>0){
			flag2=true;
		}
		
		if(flag1&&flag2){
			flag=true;
		}
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
	finally{
		DBUtil.closeAll(conn, pst, null);
	}
	return flag;	
	}
	
	/*
	 * 根据订单号查询发货信息表
	 */
	public ShipmentsInfo selectShipmentsInfoByorder_id(int order_id){
		ShipmentsInfo sp=new ShipmentsInfo();
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="select * from shipmentsInfo where order_id=?";
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, order_id);
			rs=pst.executeQuery();
			if(rs.next()){
				sp.setOrder_id(rs.getInt(1));
				sp.setP_id(rs.getInt(2));
				sp.setShipment_adress(rs.getString(3));
				sp.setOrder_adress(rs.getString(4));
				sp.setExpress(rs.getString(5));
				sp.setShip_state(rs.getString(6));
				sp.setUsername(rs.getString(7));
				sp.setShipments_date(rs.getDate(8));								
			}		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		return sp;
	}
	
	
	
	
	
	/*
	 * 根据订单号查询订单
	 */
	
	public Orders selectOrderByorder_id(int order_id){
		Orders od=new Orders();
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="select * from orders where order_id=?";
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, order_id);
			rs=pst.executeQuery();
			if(rs.next()){
				od.setOrder_id(rs.getInt(1));
				od.setP_id(rs.getInt(2));
				od.setP_name(rs.getString(3));
				od.setP_price(rs.getDouble(4));
				od.setP_quantity(rs.getInt(5));
				od.setOrder_sum(rs.getDouble(6));
				od.setOrder_user(rs.getString(7));
				od.setOreder_phone(rs.getString(8));
				od.setOrder_adres(rs.getString(9));
				od.setOrder_date(rs.getDate(10));
				od.setUsername(rs.getString(11));
				od.setOrder_state(rs.getString(12));
				od.setOrder_save(rs.getString(13));				
			}		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		return od;
	}
	
	
	/*
	 *查询所有订单
	 *分页查询
	 */	
	public ArrayList<Orders> getPOrders(int pageNo,int pageSize){
		ArrayList<Orders> list=new ArrayList<Orders>();
		String sql="select * from (select row_number() over(order by order_id) rn,p.*from orders p)where rn between ? and ?";	
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(1, start);
			pst.setInt(2, end);
			
			rs=pst.executeQuery();			
			while(rs.next()){
				Orders od=new Orders();
				od.setOrder_id(rs.getInt(2));
				od.setP_id(rs.getInt(3));
				od.setP_name(rs.getString(4));
				od.setP_price(rs.getDouble(5));
				od.setP_quantity(rs.getInt(6));
				od.setOrder_sum(rs.getDouble(7));
				od.setOrder_user(rs.getString(8));
				od.setOreder_phone(rs.getString(9));
				od.setOrder_adres(rs.getString(10));
				od.setOrder_date(rs.getDate(11));
				od.setUsername(rs.getString(12));
				od.setOrder_state(rs.getString(13));
				od.setOrder_save(rs.getString(14));	
				list.add(od);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	
	public int getCount(){
		int total=0;
		String sql="select count(*) from orders";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	/*
	 *根据商品编号p_id查询所有订单
	 *分页查询
	 */	
	public ArrayList<Orders> getOrdersByP_id(int p_id,int pageNo,int pageSize){
		ArrayList<Orders> list=new ArrayList<Orders>();
		String sql="select * from (select row_number() over(order by order_id) rn,p.*from orders p where p_id=?)where rn between ? and ?";	
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, p_id);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(2, start);
			pst.setInt(3, end);
			
			rs=pst.executeQuery();			
			while(rs.next()){
				Orders od=new Orders();
				od.setOrder_id(rs.getInt(2));
				od.setP_id(rs.getInt(3));
				od.setP_name(rs.getString(4));
				od.setP_price(rs.getDouble(5));
				od.setP_quantity(rs.getInt(6));
				od.setOrder_sum(rs.getDouble(7));
				od.setOrder_user(rs.getString(8));
				od.setOreder_phone(rs.getString(9));
				od.setOrder_adres(rs.getString(10));
				od.setOrder_date(rs.getDate(11));
				od.setUsername(rs.getString(12));
				od.setOrder_state(rs.getString(13));
				od.setOrder_save(rs.getString(14));	
				list.add(od);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	
	public int getCountByP_id(int p_id){
		int total=0;
		String sql="select count(*) from orders where p_id=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, p_id);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	/*
	 *根据发货状态Order_state查询所有订单
	 *分页查询
	 */	
	public ArrayList<Orders> getOrdersByOrder_state(String order_state,int pageNo,int pageSize){
		ArrayList<Orders> list=new ArrayList<Orders>();
		String sql="select * from (select row_number() over(order by order_id) rn,p.*from orders p where order_state=?)where rn between ? and ?";	
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, order_state);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(2, start);
			pst.setInt(3, end);
			
			rs=pst.executeQuery();			
			while(rs.next()){
				Orders od=new Orders();
				od.setOrder_id(rs.getInt(2));
				od.setP_id(rs.getInt(3));
				od.setP_name(rs.getString(4));
				od.setP_price(rs.getDouble(5));
				od.setP_quantity(rs.getInt(6));
				od.setOrder_sum(rs.getDouble(7));
				od.setOrder_user(rs.getString(8));
				od.setOreder_phone(rs.getString(9));
				od.setOrder_adres(rs.getString(10));
				od.setOrder_date(rs.getDate(11));
				od.setUsername(rs.getString(12));
				od.setOrder_state(rs.getString(13));
				od.setOrder_save(rs.getString(14));	
				list.add(od);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	
	public int getCountByOrder_state(String order_state){
		int total=0;
		String sql="select count(*) from orders where order_state=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, order_state);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	/*
	 *根据订单状态Order_save查询所有订单
	 *分页查询
	 */	
	public ArrayList<Orders> getOrdersByOrder_save(String order_save,int pageNo,int pageSize){
		ArrayList<Orders> list=new ArrayList<Orders>();
		String sql="select * from (select row_number() over(order by order_id) rn,p.*from orders p where order_save=?)where rn between ? and ?";	
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, order_save);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(2, start);
			pst.setInt(3, end);
			
			rs=pst.executeQuery();			
			while(rs.next()){
				Orders od=new Orders();
				od.setOrder_id(rs.getInt(2));
				od.setP_id(rs.getInt(3));
				od.setP_name(rs.getString(4));
				od.setP_price(rs.getDouble(5));
				od.setP_quantity(rs.getInt(6));
				od.setOrder_sum(rs.getDouble(7));
				od.setOrder_user(rs.getString(8));
				od.setOreder_phone(rs.getString(9));
				od.setOrder_adres(rs.getString(10));
				od.setOrder_date(rs.getDate(11));
				od.setUsername(rs.getString(12));
				od.setOrder_state(rs.getString(13));
				od.setOrder_save(rs.getString(14));	
				list.add(od);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	
	public int getCountByOrder_save(String order_save){
		int total=0;
		String sql="select count(*) from orders where order_save=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, order_save);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	/*
	 *根据订单状态Order_save查询所有订单
	 *分页查询
	 */	
	public ArrayList<Orders> getOrdersByUsername(String username,int pageNo,int pageSize){
		ArrayList<Orders> list=new ArrayList<Orders>();
		String sql="select * from (select row_number() over(order by order_id) rn,p.*from orders p where username=?)where rn between ? and ?";	
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, username);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(2, start);
			pst.setInt(3, end);
			
			rs=pst.executeQuery();			
			while(rs.next()){
				Orders od=new Orders();
				od.setOrder_id(rs.getInt(2));
				od.setP_id(rs.getInt(3));
				od.setP_name(rs.getString(4));
				od.setP_price(rs.getDouble(5));
				od.setP_quantity(rs.getInt(6));
				od.setOrder_sum(rs.getDouble(7));
				od.setOrder_user(rs.getString(8));
				od.setOreder_phone(rs.getString(9));
				od.setOrder_adres(rs.getString(10));
				od.setOrder_date(rs.getDate(11));
				od.setUsername(rs.getString(12));
				od.setOrder_state(rs.getString(13));
				od.setOrder_save(rs.getString(14));	
				list.add(od);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	
	public int getCountByUsername(String username){
		int total=0;
		String sql="select count(*) from orders where username=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, username);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	/*
	 * 修改订单表的订单状态
	 */
	
	public boolean updateOrderByOrder_save(int order_id,String order_save){
		boolean flag=false;
		Connection conn=null;
		PreparedStatement pst=null;
		String sql="update orders set order_save=? where order_id=?";
		
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, order_save);
			pst.setInt(2, order_id);
			int rows=pst.executeUpdate();
			if(rows>0){
				flag=true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst,null);
		}			
		return flag;		
	}
	
	
	
	/*
	 * 查询所有用户信息
	 * 分页查询
	 */
	public ArrayList<Customer> getCustomer(int pageNo,int pageSize){
		ArrayList<Customer> list=new ArrayList<Customer>();
		String sql="select * from (select row_number() over(order by userid) rn,p.*from Customer p where mold=? )where rn between ? and ?";	
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, "用户");
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(2, start);
			pst.setInt(3, end);
			
			rs=pst.executeQuery();			
			while(rs.next()){
				Customer ct=new Customer();
				ct.setUserId(rs.getInt(2));
				ct.setUserName(rs.getString(3));
				ct.setPassword(rs.getString(4));
				ct.setMold(rs.getString(5));
				ct.setTrueName(rs.getString(6));
				ct.setSex(rs.getString(7));
				ct.setPhone(rs.getString(8));
				ct.setEmail(rs.getString(9));
				ct.setAddress(rs.getString(10));
				ct.setDate(rs.getDate(11));
				list.add(ct);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	
	public int getCountCustomer(){
		int total=0;
		String sql="select count(*) from customer where mold=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, "用户");
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	
	
	
}
	
