package dao;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.ProductDto;

import util.DBUtil;
import bean.Assess;
import bean.Customer;
import bean.Orders;
import bean.Product;
import bean.ShipmentsInfo;

public class CustomerDao {
	
	/*
	 * 商品信息
	 */
	
	
	/*
	 *根据p_type查询单件商品
	 *分页查询
	 */	
	public ArrayList<Product> getProductByP_type(String p_type,int pageNo,int pageSize){
		ArrayList<Product> list=new ArrayList<Product>();
		String sql="select * from (select row_number() over(order by p_id) rn,p.*from Product p where p_type=?)where rn between ? and ?";	
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, p_type);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(2, start);
			pst.setInt(3, end);
			
			rs=pst.executeQuery();			
			while(rs.next()){
				Product pt=new Product();
				pt.setP_id(rs.getInt(2));
				pt.setP_name(rs.getString(3));
				pt.setP_price(rs.getDouble(4));
				pt.setP_quantity(rs.getInt(5));
				pt.setP_type(rs.getString(6));
				pt.setP_var(rs.getString(7));
				pt.setP_image(rs.getString(8));
				list.add(pt);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	
	public int getCountByP_type(String p_type){
		int total=0;
		String sql="select count(*) from Product where p_type=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, p_type);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	
	/*
	 * 查询所有
	 * 分页查询的记录数
	 */
	public ArrayList<Product> getByPage(int pageNo,int pageSize){
		ArrayList<Product> list=new ArrayList<Product>();
		String sql="select * from (select row_number() over(order by p_id) rn,p.*from Product p)where rn between ? and ?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(1, start);
			pst.setInt(2, end);
						
			rs=pst.executeQuery();
			while(rs.next()){
				Product pt=new Product();
				pt.setP_id(rs.getInt(2));
				pt.setP_name(rs.getString(3));
				pt.setP_price(rs.getDouble(4));
				pt.setP_quantity(rs.getInt(5));
				pt.setP_type(rs.getString(6));
				pt.setP_var(rs.getString(7));
				pt.setP_image(rs.getString(8));				
				list.add(pt);				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		return list;
	}
	
	/*
	 * 查询所有
	 * 查询总记录数
	 */
	public int getCount(){
		int total=0;
		String sql="select count(*) from Product";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	
	
	
	
	
	/*
	 * 
	 * 高级查询商品
	 */
	public ArrayList<Product> getAdvanceSelect(ProductDto pto,int pageNo,int pageSize){
		ArrayList<Product> list=new ArrayList<Product>();
		String sql="select * from (select row_number() over(order by p_id) rn,p.*from Product p where 1=1 ";
	
		if(pto!=null){
			if(pto.getSearch_p_name()!=null&&!"".equals(pto.getSearch_p_name())){
				sql+=" and p_name like '%"+pto.getSearch_p_name()+"%'";				
			}
			if(pto.getSearch_down_p_price()>0&&pto.getSearch_up_p_price()>0){
				sql+=" and p_price between "+pto.getSearch_down_p_price()+" and "+pto.getSearch_up_p_price();									
			}
			if(pto.getSearch_p_type()!=null && !"".equals(pto.getSearch_p_type())){
				sql+=" and p_type like '%"+pto.getSearch_p_type()+"%'";
			}
			if(pto.getSearch_p_var()!=null&& !"".equals(pto.getSearch_p_var())){
				sql+=" and p_var like '%"+pto.getSearch_p_var()+"%'";				
			}			
		}
		sql+=")where rn between ? and ?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(1, start);
			pst.setInt(2, end);
			rs=pst.executeQuery();
			
			while(rs.next()){
				Product pt=new Product();
				pt.setP_id(rs.getInt(2));
				pt.setP_name(rs.getString(3));
				pt.setP_price(rs.getDouble(4));
				pt.setP_quantity(rs.getInt(5));
				pt.setP_type(rs.getString(6));
				pt.setP_var(rs.getString(7));
				pt.setP_image(rs.getString(8));				
				list.add(pt);				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	public int getCountAdvanceSelect(ProductDto pto){
		int total=0;
		String sql="select count(*) from Product where 1=1";
		if(pto!=null){
			if(pto.getSearch_p_name()!=null&&!"".equals(pto.getSearch_p_name())){
				sql+=" and p_name like '%"+pto.getSearch_p_name()+"%'";				
			}
			if(pto.getSearch_down_p_price()>0&&pto.getSearch_up_p_price()>0){
				sql+=" and p_price between "+pto.getSearch_down_p_price()+" and "+pto.getSearch_up_p_price();									
			}
			if(pto.getSearch_p_type()!=null && !"".equals(pto.getSearch_p_type())){
				sql+=" and p_type like '%"+pto.getSearch_p_type()+"%'";
			}
			if(pto.getSearch_p_var()!=null&& !"".equals(pto.getSearch_p_var())){
				sql+=" and p_var like '%"+pto.getSearch_p_var()+"%'";				
			}			
		}
		
		
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	/*
	 * 通过文本框的值去查询相关的信息
	 * 查询商品
	 */
	public ArrayList<Product> getAdvanceSelect1(String txtname,int pageNo,int pageSize){
		ArrayList<Product> list=new ArrayList<Product>();
		String sql="select * from (select row_number() over(order by p_id) rn,p.*from Product p where p_name like ? or p_type like ? or p_var like ?)where rn between ? and ?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setString(1, "%"+txtname+"%");
			pst.setString(2, "%"+txtname+"%");
			pst.setString(3, "%"+txtname+"%");
			pst.setInt(4, start);
			pst.setInt(5, end);
			rs=pst.executeQuery();
			
			while(rs.next()){
				Product pt=new Product();
				pt.setP_id(rs.getInt(2));
				pt.setP_name(rs.getString(3));
				pt.setP_price(rs.getDouble(4));
				pt.setP_quantity(rs.getInt(5));
				pt.setP_type(rs.getString(6));
				pt.setP_var(rs.getString(7));
				pt.setP_image(rs.getString(8));				
				list.add(pt);				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	public int getCountAdvanceSelect1(String txtname){
		int total=0;
		String sql="select count(*) from Product where p_name like ? or p_type like ? or p_var like ?";				
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, "%"+txtname+"%");
			pst.setString(2, "%"+txtname+"%");
			pst.setString(3, "%"+txtname+"%");
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	
	
	/*
	 *查询所有商品
	 */	
	public ArrayList<Product> getAllProduct(){
		ArrayList<Product> list=new ArrayList<Product>();
		String sql="select * from Product ";		
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			rs=pst.executeQuery();			
			while(rs.next()){
				Product pt=new Product();
				pt.setP_id(rs.getInt(1));
				pt.setP_name(rs.getString(2));
				pt.setP_price(rs.getDouble(3));
				pt.setP_quantity(rs.getInt(4));
				pt.setP_type(rs.getString(5));
				pt.setP_var(rs.getString(6));
				pt.setP_image(rs.getString(7));				
				list.add(pt);				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return list;		
	}
	
	/*
	 *根据p_id查询单件商品
	 */	
	public Product getProductByP_id(int p_id){
		Product pt=new Product();
		String sql="select * from product where p_id=?";		
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, p_id);
			rs=pst.executeQuery();			
			if(rs.next()){				
				pt.setP_id(rs.getInt(1));
				pt.setP_name(rs.getString(2));
				pt.setP_price(rs.getDouble(3));
				pt.setP_quantity(rs.getInt(4));
				pt.setP_type(rs.getString(5));
				pt.setP_var(rs.getString(6));
				pt.setP_image(rs.getString(7));								
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return pt;		
	}
	
	
	/*
	 *根据p_name查询单件商品
	 */	
	public Product getProductByP_name(String p_name){
		Product pt=new Product();
		String sql="select * from product where p_name=?";		
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, p_name);
			rs=pst.executeQuery();			
			if(rs.next()){				
				pt.setP_id(rs.getInt(1));
				pt.setP_name(rs.getString(2));
				pt.setP_price(rs.getDouble(3));
				pt.setP_quantity(rs.getInt(4));
				pt.setP_type(rs.getString(5));
				pt.setP_var(rs.getString(6));
				pt.setP_image(rs.getString(7));								
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}						
		return pt;		
	}
	
	
	/*
	 * 根据p_id和购买数量
	 * 修改商品表对应的数量
	 */
	public boolean updateProductByP_quantity(int p_id,int num){
		boolean flag=false;
		String sql="update Product set p_quantity=p_quantity-? where p_id=?";
		Connection conn=null;
		PreparedStatement pst=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, num);
			pst.setInt(2, p_id);
			
			int rows=pst.executeUpdate();
			if(rows>0){
				flag=true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.closeAll(conn, pst, null);
		}
		
		return flag;
	}
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * 用户信息
	 */
	
	/*
	 * 登录
	 * 通过由文本框传过的值（用户账户和密码）查询数据，返回Customer对象
	 */
	public Customer selectCustomer(String username,String password){
		Customer ct=new Customer();
		String sql="select * from CUSTOMER where username=? and password=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, username);
			pst.setString(2, password);
			rs=pst.executeQuery();
			if(rs.next()){
				ct.setUserId(rs.getInt(1));
				ct.setUserName(rs.getString(2));
				ct.setPassword(rs.getString(3));
				ct.setMold(rs.getString(4));
				ct.setTrueName(rs.getString(5));
				ct.setSex(rs.getString(6));
				ct.setPhone(rs.getString(7));
				ct.setEmail(rs.getString(8));
				ct.setAddress(rs.getString(9));
				ct.setDate(rs.getDate(10));								
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		return ct;
	}
	
	

	
	
	/*
	 * 注册
	 * 向用户信息表中添加数据
	 * ID，用户账号，真实姓名，性别，手机号码，邮箱，地址
	 */
	public boolean insertCustomer(Customer ct) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		String sql = "insert into Customer(username,password,truename,sex,phone,email,address,mold) values(?,?,?,?,?,?,?,?)";
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1, ct.getUserName());
			pst.setString(2, ct.getPassword());
			pst.setString(3, ct.getTrueName());
			pst.setString(4, ct.getSex());
			pst.setString(5, ct.getPhone());
			pst.setString(6, ct.getEmail());
			pst.setString(7, ct.getAddress());
			pst.setString(8, "用户");
			int rows = pst.executeUpdate();
			if (rows > 0) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, null);
		}
		return flag;
	}
	
	/*
	 * 查询个人信息
	 */
	public Customer selectCustomerByUserName(String username){
		Customer ct=new Customer();
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		String sql="select * from Customer where username=?";
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, username);
			rs=pst.executeQuery();
			if(rs.next()){
				ct.setUserId(rs.getInt(1));
				ct.setUserName(rs.getString(2));
				ct.setPassword(rs.getString(3));
				ct.setMold(rs.getString(4));
				ct.setTrueName(rs.getString(5));
				ct.setSex(rs.getString(6));
				ct.setPhone(rs.getString(7));
				ct.setEmail(rs.getString(8));
				ct.setAddress(rs.getString(9));
				ct.setDate(rs.getDate(10));				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, rs);
		}		
		return ct;
		
	}

	
	/*
	 * 根据当前用户账号
	 * 修改用户信息表中的真实姓名，性别，手机号码，邮箱，地址
	 */
	public boolean updateCustomer(Customer ct) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		String sql = "update Customer set TrueName=?,sex=?,phone=?,email=?,address=? where username=?";
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1, ct.getTrueName());
			pst.setString(2, ct.getSex());
			pst.setString(3, ct.getPhone());			
			pst.setString(4, ct.getEmail());
			pst.setString(5, ct.getAddress());
			pst.setString(6, ct.getUserName());			
			int rows = pst.executeUpdate();
			if (rows > 0) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, null);
		}
		return flag;
	}
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * 订单信息
	 */
	
	/*
	 * 个人订单查询
	 * 分页查询
	 */
	public ArrayList<Orders> selectOrdersByUsername(String username,int pageNo,int pageSize) {
		ArrayList<Orders> list = new ArrayList<Orders>();
		String sql="select * from (select row_number() over(order by order_id) rn,p.*from Orders p where username=?)where rn between ? and ?";
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1, username);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(2, start);
			pst.setInt(3, end);
			rs = pst.executeQuery();
			while (rs.next()) {
				Orders od = new Orders();
				od.setOrder_id(rs.getInt(2));
				od.setP_id(rs.getInt(3));
				od.setP_name(rs.getString(4));
				od.setP_price(rs.getDouble(5));
				od.setP_quantity(rs.getInt(6));
				od.setOrder_sum(rs.getDouble(7));
				od.setOrder_user(rs.getString(8));
				od.setOreder_phone(rs.getString(9));
				od.setOrder_adres(rs.getString(10));
				od.setOrder_date(rs.getDate(11));
				od.setUsername(rs.getString(12));
				od.setOrder_state(rs.getString(13));
				od.setOrder_save(rs.getString(14));
				list.add(od);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, rs);
		}
		return list;
	}
	
	/*
	 * 分页查询，查询总记录数
	 */
	public int getCountOrders(String username){
		int total=0;
		String sql="select count(*) from Orders where username=? ";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, username);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	/*
	 * 结账
	 * 向订单信息表(Orders)中添加数据
	 */
	public boolean insertOrders(Orders od) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		String sql = "insert into Orders(p_id,p_name,p_price,p_quantity,order_sum,Order_user,Order_phone,Order_adres,username) values(?,?,?,?,?,?,?,?,?)";
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setInt(1, od.getP_id());
			pst.setString(2, od.getP_name());
			pst.setDouble(3, od.getP_price());
			pst.setInt(4, od.getP_quantity());
			pst.setDouble(5, od.getOrder_sum());
			pst.setString(6, od.getOrder_user());
			pst.setString(7, od.getOreder_phone());
			pst.setString(8, od.getOrder_adres());
			pst.setString(9, od.getUsername());
			
			int rows = pst.executeUpdate();
			if (rows > 0) {
				flag = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			DBUtil.closeAll(conn, pst, null);
		}
		return flag;
	}
	
	
	
	

	
	
	
	
	
	
	
	
	
	/*
	 * 发货信息
	 */
	
	/*
	 * 个人发货状态查询所有
	 * 根据用户查询未收货的信息
	 */
	public ArrayList<ShipmentsInfo> selectShipmentInfoByUsername1(String username,int pageNo,int pageSize) {
		ArrayList<ShipmentsInfo> list = new ArrayList<ShipmentsInfo>();
		String sql="select * from (select row_number() over(order by order_id) rn,p.*from ShipmentsInfo p where username=? and Ship_state=?)where rn between ? and ?";
		Connection conn = null;
		PreparedStatement pst = null;	
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1, username);
			pst.setString(2, "已收货");
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(3, start);
			pst.setInt(4, end);
			rs = pst.executeQuery();
			while (rs.next()) {
				ShipmentsInfo sp = new ShipmentsInfo();
				sp.setOrder_id(rs.getInt(2));
				sp.setP_id(rs.getInt(3));
				sp.setShipment_adress(rs.getString(4));
				sp.setOrder_adress(rs.getString(5));
				sp.setExpress(rs.getString(6));
				sp.setShip_state(rs.getString(7));
				sp.setUsername(rs.getString(8));
				sp.setShipments_date(rs.getDate(9));
				list.add(sp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, rs);
		}
		return list;
	}
	
	
	public int getCountShipmentsInfo1(String username){
		int total=0;
		String sql="select count(*) from ShipmentsInfo where username=? and Ship_state=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, username);
			pst.setString(2, "已收货");
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	/*
	 * 个人发货状态查询所有
	 * 根据用户查询未收货的信息
	 */
	public ArrayList<ShipmentsInfo> selectShipmentInfoByUsername(String username,int pageNo,int pageSize) {
		ArrayList<ShipmentsInfo> list = new ArrayList<ShipmentsInfo>();
		String sql="select * from (select row_number() over(order by order_id) rn,p.*from ShipmentsInfo p where username=? and Ship_state=?)where rn between ? and ?";
		Connection conn = null;
		PreparedStatement pst = null;	
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1, username);
			pst.setString(2, "未收货");
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(3, start);
			pst.setInt(4, end);
			rs = pst.executeQuery();
			while (rs.next()) {
				ShipmentsInfo sp = new ShipmentsInfo();
				sp.setOrder_id(rs.getInt(2));
				sp.setP_id(rs.getInt(3));
				sp.setShipment_adress(rs.getString(4));
				sp.setOrder_adress(rs.getString(5));
				sp.setExpress(rs.getString(6));
				sp.setShip_state(rs.getString(7));
				sp.setUsername(rs.getString(8));
				sp.setShipments_date(rs.getDate(9));
				list.add(sp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, rs);
		}
		return list;
	}
	
	
	public int getCountShipmentsInfo(String username){
		int total=0;
		String sql="select count(*) from ShipmentsInfo where username=? and Ship_state=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, username);
			pst.setString(2, "未收货");
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	/*
	 * 	收获确认
	 */
	public boolean updateShipmentsInatefoSt(int order_id) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		String sql = "update ShipmentsInfo set ship_state=? where order_id=?";
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1, "已收货");
			pst.setInt(2, order_id);
			int rows = pst.executeUpdate();
			if (rows > 0) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, null);
		}
		return flag;

	}
	
	// 向商品评价表添加数据
	public boolean insertAssess(Assess ass) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pst = null;
		String sql = "insert into Assess(p_id,username,wares_asses) values(?,?,?)";
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setInt(1, ass.getP_id());
			pst.setString(2, ass.getUserName());
			pst.setString(3, ass.getWares_asses());
			int rows = pst.executeUpdate();
			if (rows > 0) {
				flag = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, null);
		}

		return flag;

	}
			
	/*
	 * 查询商品评价，根据商品编号p_id
	 * 分页查询
	 */
	public ArrayList<Assess> getAssessByP_id(int p_id,int pageNo,int pageSize){
		ArrayList<Assess> list=new ArrayList<Assess>();
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		String sql="select * from (select row_number() over(order by p_id) rn,p.*from Assess p where p_id=?)where rn between ? and ?";
		
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, p_id);
			//确定查询的起始记录
			int start=(pageNo-1)*pageSize+1;
			//确定查询的结束记录		
			int end=pageNo*pageSize;
			pst.setInt(2, start);
			pst.setInt(3, end);
			rs=pst.executeQuery();
			while(rs.next()){
				Assess as=new Assess();
				as.setA_id(rs.getInt(2));
				as.setP_id(rs.getInt(3));
				as.setUserName(rs.getString(4));
				as.setWares_asses(rs.getString(5));
				list.add(as);				
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, rs);
		}		
		return list;
		
	}
	
	
	
	
	public int getCountAssess(int p_id){
		int total=0;
		String sql="select count(*) from Assess where p_id=?";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, p_id);
			rs=pst.executeQuery();
			
			if(rs.next()){
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(conn, pst, rs);
		}				
		
		return total;
	}
	
	
	
	

}
