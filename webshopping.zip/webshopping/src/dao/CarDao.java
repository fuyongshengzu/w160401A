package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBUtil;

import bean.Car;

public class CarDao {
	
	/*
	 * 添加数据
	 */
	
	public boolean insertCar(Car car){
		boolean flag=false;
		String sql="insert into Car values(?,?,?,?,?,?)";
		Connection conn=null;
		PreparedStatement pst = null;
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			pst.setInt(1, car.getP_id());
			pst.setString(2, car.getP_name());
			pst.setDouble(3, car.getP_price());
			pst.setInt(4, car.getOrder_count());
			pst.setDouble(5, car.getP_price()*car.getOrder_count());
			pst.setString(6, car.getUsername());
			int rows = pst.executeUpdate();
			if (rows > 0) {
				flag = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			DBUtil.closeAll(conn, pst, null);
		}		
		return flag;
	}
	
	
	/*
	 * 根据p_id和当前用户判断购物信息表是否存在
	 */
	public Car selectCarByP_id(int p_id,String username){
		Car car=new Car();
		String sql="select * from car where p_id=? and username=?";
		Connection conn=null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, p_id);
			pst.setString(2, username);
			rs=pst.executeQuery();
			if(rs.next()){
				car.setP_id(rs.getInt(1));
				car.setP_name(rs.getString(2));
				car.setP_price(rs.getDouble(3));
				car.setOrder_count(rs.getInt(4));
				car.setOrder_sum(rs.getDouble(5));
				car.setUsername(rs.getString(6));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, rs);
		}		
		
		return car;
	}
	
	/*
	 * 对当前用户
	 * 根据p_id修改数量
	 */
	public boolean updateCarByP_id(Car car){
		boolean flag=false;
		String sql="update car set order_count=?,order_sum=? where p_id=? and username=?";
		Connection conn=null;
		PreparedStatement pst = null;
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, car.getOrder_count());
			pst.setDouble(2, car.getOrder_sum());
			pst.setInt(3, car.getP_id());
			pst.setString(4, car.getUsername());
			int rows=pst.executeUpdate();
			if(rows>0){
				flag=true;
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.closeAll(conn, pst, null);
		}	
				
		return flag;
		
	}
	
	/*
	 * 根据当前用户查询购物车信息
	 * 查询所有信息
	 */
	public ArrayList<Car> selectAll(String username){
		ArrayList<Car> list=new ArrayList<Car>();
		String sql="select * from car where username=?";
		Connection conn=null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, username);
			rs=pst.executeQuery();
			while(rs.next()){
				Car car=new Car();
				car.setP_id(rs.getInt(1));
				car.setP_name(rs.getString(2));
				car.setP_price(rs.getDouble(3));
				car.setOrder_count(rs.getInt(4));
				car.setOrder_sum(rs.getDouble(5));
				car.setUsername(rs.getString(6));
				list.add(car);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, pst, rs);
		}				
		return list;
	}
	
	/*
	 * 从购物车里删除单件商品,根据p_id和username
	 */
	
	public boolean deleteByP_id(int p_id,String username){
		boolean flag=false;
		Connection conn=null;
		PreparedStatement pst = null;
		String sql="delete from car where p_id=? and username=?";
		
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, p_id);
			pst.setString(2, username);
			int rows=pst.executeUpdate();
			if(rows>0){
				flag=true;
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.closeAll(conn, pst, null);
		}			
		return flag;
		
	}

	/*
	 * 从购物车里删除用户所有商品,根据username
	 */
	
	public boolean deleteBAll(String username){
		boolean flag=false;
		Connection conn=null;
		PreparedStatement pst = null;
		String sql="delete from car where username=?";
		
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(sql);
			pst.setString(1, username);
			int rows=pst.executeUpdate();
			if(rows>0){
				flag=true;
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.closeAll(conn, pst, null);
		}			
		return flag;
		
	}
	
	
}
