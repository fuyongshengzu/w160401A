package bean;

public class Car {
	private int p_id;
	private String p_name;
	private double p_price;
	private int order_count;
	private double order_sum;
	private String username;
	/**
	 * 
	 */
	public Car() {
		super();
		// TODO 自动生成的构造函数存根
	}
	
	
	/**
	 * @param p_id
	 * @param p_name
	 * @param p_price
	 * @param order_count
	 * @param order_sum
	 * @param username
	 */
	public Car(int p_id, String p_name, double p_price, int order_count,
			double order_sum, String username) {
		super();
		this.p_id = p_id;
		this.p_name = p_name;
		this.p_price = p_price;
		this.order_count = order_count;
		this.order_sum = order_sum;
		this.username = username;
	}


	/**
	 * @return p_id
	 */
	public int getP_id() {
		return p_id;
	}
	/**
	 * @param p_id 要设置的 p_id
	 */
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	/**
	 * @return p_name
	 */
	public String getP_name() {
		return p_name;
	}
	/**
	 * @param p_name 要设置的 p_name
	 */
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	/**
	 * @return p_price
	 */
	public double getP_price() {
		return p_price;
	}
	/**
	 * @param p_price 要设置的 p_price
	 */
	public void setP_price(double p_price) {
		this.p_price = p_price;
	}
	/**
	 * @return order_count
	 */
	public int getOrder_count() {		
		return order_count;
	}
	/**
	 * @param order_count 要设置的 order_count
	 */
	public void setOrder_count(int order_count) {
		this.order_count = order_count;
	}
	/**
	 * @return order_sum
	 */
	public double getOrder_sum() {
		return order_sum;
	}
	/**
	 * @param order_sum 要设置的 order_sum
	 */
	public void setOrder_sum(double order_sum) {
		this.order_sum = order_sum;
	}


	/**
	 * @return username
	 */
	public String getUsername() {
		return username;
	}


	/**
	 * @param username 要设置的 username
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	
	

}
