package bean;

import java.sql.Date;

/*
 * 用户信息类
 */
public class Customer {
	private int UserId;
	private String UserName;
	private String Password;
	private String mold;
	private String TrueName;
	private String sex;
	private String phone;
	private String Email;
	private String Address;
	private Date date;
	/**
	 * 
	 */
	public Customer() {
		super();
		// TODO 自动生成的构造函数存根
	}
	/**
	 * @param userId
	 * @param userName
	 * @param password
	 * @param mold
	 * @param trueName
	 * @param sex
	 * @param phone
	 * @param email
	 * @param address
	 * @param date
	 */
	public Customer(int userId, String userName, String password, String mold,
			String trueName, String sex, String phone, String email,
			String address, Date date) {
		super();
		UserId = userId;
		UserName = userName;
		Password = password;
		this.mold = mold;
		TrueName = trueName;
		this.sex = sex;
		this.phone = phone;
		Email = email;
		Address = address;
		this.date = date;
	}
	/**
	 * @return userId
	 */
	public int getUserId() {
		return UserId;
	}
	/**
	 * @param userId 要设置的 userId
	 */
	public void setUserId(int userId) {
		UserId = userId;
	}
	/**
	 * @return userName
	 */
	public String getUserName() {
		return UserName;
	}
	/**
	 * @param userName 要设置的 userName
	 */
	public void setUserName(String userName) {
		UserName = userName;
	}
	/**
	 * @return password
	 */
	public String getPassword() {
		return Password;
	}
	/**
	 * @param password 要设置的 password
	 */
	public void setPassword(String password) {
		Password = password;
	}
	/**
	 * @return mold
	 */
	public String getMold() {
		return mold;
	}
	/**
	 * @param mold 要设置的 mold
	 */
	public void setMold(String mold) {
		this.mold = mold;
	}
	/**
	 * @return trueName
	 */
	public String getTrueName() {
		return TrueName;
	}
	/**
	 * @param trueName 要设置的 trueName
	 */
	public void setTrueName(String trueName) {
		TrueName = trueName;
	}
	/**
	 * @return sex
	 */
	public String getSex() {
		return sex;
	}
	/**
	 * @param sex 要设置的 sex
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	/**
	 * @return phone
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * @param phone 要设置的 phone
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * @return email
	 */
	public String getEmail() {
		return Email;
	}
	/**
	 * @param email 要设置的 email
	 */
	public void setEmail(String email) {
		Email = email;
	}
	/**
	 * @return address
	 */
	public String getAddress() {
		return Address;
	}
	/**
	 * @param address 要设置的 address
	 */
	public void setAddress(String address) {
		Address = address;
	}
	/**
	 * @return date
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * @param date 要设置的 date
	 */
	public void setDate(Date date) {
		this.date = date;
	}
	
	

}
