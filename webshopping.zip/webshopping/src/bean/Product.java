package bean;

public class Product { 
	private int p_id;
	private String p_name;
	private double p_price;
	private int p_quantity;
	private String p_type;
	private String p_var;
	private String p_image;
	/**
	 * @return p_id
	 */
	public int getP_id() {
		return p_id;
	}
	/**
	 * @param p_id 要设置的 p_id
	 */
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	/**
	 * @return p_name
	 */
	public String getP_name() {
		return p_name;
	}
	/**
	 * @param p_name 要设置的 p_name
	 */
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	/**
	 * @return p_price
	 */
	public double getP_price() {
		return p_price;
	}
	/**
	 * @param p_price 要设置的 p_price
	 */
	public void setP_price(double p_price) {
		this.p_price = p_price;
	}
	/**
	 * @return p_quantity
	 */
	public int getP_quantity() {
		return p_quantity;
	}
	/**
	 * @param p_quantity 要设置的 p_quantity
	 */
	public void setP_quantity(int p_quantity) {
		this.p_quantity = p_quantity;
	}
	/**
	 * @return p_type
	 */
	public String getP_type() {
		return p_type;
	}
	/**
	 * @param p_type 要设置的 p_type
	 */
	public void setP_type(String p_type) {
		this.p_type = p_type;
	}
	/**
	 * @return p_var
	 */
	public String getP_var() {
		return p_var;
	}
	/**
	 * @param p_var 要设置的 p_var
	 */
	public void setP_var(String p_var) {
		this.p_var = p_var;
	}
	/**
	 * @return p_image
	 */
	public String getP_image() {
		return p_image;
	}
	/**
	 * @param p_image 要设置的 p_image
	 */
	public void setP_image(String p_image) {
		this.p_image = p_image;
	}
	/**
	 * 
	 */
	public Product() {
		super();
		// TODO 自动生成的构造函数存根
	}
	/**
	 * @param p_id
	 * @param p_name
	 * @param p_price
	 * @param p_quantity
	 * @param p_type
	 * @param p_var
	 * @param p_image
	 */
	public Product(int p_id, String p_name, double p_price, int p_quantity,
			String p_type, String p_var, String p_image) {
		super();
		this.p_id = p_id;
		this.p_name = p_name;
		this.p_price = p_price;
		this.p_quantity = p_quantity;
		this.p_type = p_type;
		this.p_var = p_var;
		this.p_image = p_image;
	}
	/* （非 Javadoc）
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Product [p_id=" + p_id + ", p_name=" + p_name + ", p_price="
				+ p_price + ", p_quantity=" + p_quantity + ", p_type=" + p_type
				+ ", p_var=" + p_var + ", p_image=" + p_image + "]";
	}
	
	
	
	

}
