package bean;

import java.sql.Date;

public class Orders {
	private int order_id;
	private int p_id;
	private String p_name;
	private double p_price;
	private int p_quantity;
	private double order_sum;
	private String Order_user;
	private String Order_adres;
	private Date Order_date;
	private String username;
	private String Order_state;
	private String Order_save;
	private String Oreder_phone;
	
	public Orders() {
		// TODO 自动生成的构造函数存根
	}






	/**
	 * @param order_id
	 * @param p_id
	 * @param p_name
	 * @param p_price
	 * @param p_quantity
	 * @param order_sum
	 * @param order_user
	 * @param order_adres
	 * @param order_date
	 * @param username
	 * @param order_state
	 * @param order_save
	 * @param oreder_phone
	 */
	public Orders(int order_id, int p_id, String p_name, double p_price,
			int p_quantity, double order_sum, String order_user,
			String order_adres, Date order_date, String username,
			String order_state, String order_save, String oreder_phone) {
		super();
		this.order_id = order_id;
		this.p_id = p_id;
		this.p_name = p_name;
		this.p_price = p_price;
		this.p_quantity = p_quantity;
		this.order_sum = order_sum;
		Order_user = order_user;
		Order_adres = order_adres;
		Order_date = order_date;
		this.username = username;
		Order_state = order_state;
		Order_save = order_save;
		Oreder_phone = oreder_phone;
	}






	/**
	 * @return order_id
	 */
	public int getOrder_id() {
		return order_id;
	}

	/**
	 * @param order_id 要设置的 order_id
	 */
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	/**
	 * @return p_id
	 */
	public int getP_id() {
		return p_id;
	}

	/**
	 * @param p_id 要设置的 p_id
	 */
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	/**
	 * @return p_price
	 */
	public double getP_price() {
		return p_price;
	}

	/**
	 * @param p_price 要设置的 p_price
	 */
	public void setP_price(double p_price) {
		this.p_price = p_price;
	}

	/**
	 * @return p_quantity
	 */
	public int getP_quantity() {
		return p_quantity;
	}

	/**
	 * @param p_quantity 要设置的 p_quantity
	 */
	public void setP_quantity(int p_quantity) {
		this.p_quantity = p_quantity;
	}

	/**
	 * @return order_sum
	 */
	public double getOrder_sum() {
		return order_sum;
	}

	/**
	 * @param order_sum 要设置的 order_sum
	 */
	public void setOrder_sum(double order_sum) {
		this.order_sum = order_sum;
	}

	/**
	 * @return order_user
	 */
	public String getOrder_user() {
		return Order_user;
	}

	/**
	 * @param order_user 要设置的 order_user
	 */
	public void setOrder_user(String order_user) {
		Order_user = order_user;
	}

	/**
	 * @return order_adres
	 */
	public String getOrder_adres() {
		return Order_adres;
	}

	/**
	 * @param order_adres 要设置的 order_adres
	 */
	public void setOrder_adres(String order_adres) {
		Order_adres = order_adres;
	}

	/**
	 * @return order_date
	 */
	public Date getOrder_date() {
		return Order_date;
	}

	/**
	 * @param order_date 要设置的 order_date
	 */
	public void setOrder_date(Date order_date) {
		Order_date = order_date;
	}

	/**
	 * @return username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username 要设置的 username
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return order_state
	 */
	public String getOrder_state() {
		return Order_state;
	}

	/**
	 * @param order_state 要设置的 order_state
	 */
	public void setOrder_state(String order_state) {
		Order_state = order_state;
	}

	/**
	 * @return order_save
	 */
	public String getOrder_save() {
		return Order_save;
	}

	/**
	 * @param order_save 要设置的 order_save
	 */
	public void setOrder_save(String order_save) {
		Order_save = order_save;
	}
	
	

	/**
	 * @return oreder_phone
	 */
	public String getOreder_phone() {
		return Oreder_phone;
	}



	/**
	 * @param oreder_phone 要设置的 oreder_phone
	 */
	public void setOreder_phone(String oreder_phone) {
		Oreder_phone = oreder_phone;
	}
	
	



	/**
	 * @return p_name
	 */
	public String getP_name() {
		return p_name;
	}






	/**
	 * @param p_name 要设置的 p_name
	 */
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}






	/* （非 Javadoc）
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OrdersInfo [order_id=" + order_id + ", p_id=" + p_id
				+ ", p_price=" + p_price + ", p_quantity=" + p_quantity
				+ ", order_sum=" + order_sum + ", Order_user=" + Order_user
				+ ", Order_adres=" + Order_adres + ", Order_date=" + Order_date
				+ ", username=" + username + ", Order_state=" + Order_state
				+ ", Order_save=" + Order_save + "]";
	}
}
