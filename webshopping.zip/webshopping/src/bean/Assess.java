package bean;

public class Assess {
	private int a_id;
	private int p_id;
	private String UserName;
	private String Wares_asses;
	
	public Assess() {
		
	}

	public Assess(int a_id, int p_id, String userName, String wares_asses) {
		this.a_id = a_id;
		this.p_id = p_id;
		UserName = userName;
		Wares_asses = wares_asses;
	}

	/**
	 * @return a_id
	 */
	public int getA_id() {
		return a_id;
	}

	/**
	 * @param a_id 要设置的 a_id
	 */
	public void setA_id(int a_id) {
		this.a_id = a_id;
	}

	/**
	 * @return p_id
	 */
	public int getP_id() {
		return p_id;
	}

	/**
	 * @param p_id 要设置的 p_id
	 */
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	/**
	 * @return userName
	 */
	public String getUserName() {
		return UserName;
	}

	/**
	 * @param userName 要设置的 userName
	 */
	public void setUserName(String userName) {
		UserName = userName;
	}

	/**
	 * @return wares_asses
	 */
	public String getWares_asses() {
		return Wares_asses;
	}

	/**
	 * @param wares_asses 要设置的 wares_asses
	 */
	public void setWares_asses(String wares_asses) {
		Wares_asses = wares_asses;
	}

	/* （非 Javadoc）
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AssessInfo [a_id=" + a_id + ", p_id=" + p_id + ", UserName="
				+ UserName + ", Wares_asses=" + Wares_asses + "]";
	}
}
