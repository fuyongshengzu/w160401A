package bean;

import java.util.ArrayList;
import java.util.List;

/*
 * 封装分页所需的所有数据和方法
 */
public class PageBean<T> {
	private int pageNo;//页号
	private int pageSize;//页的大小
	private List<T> data=new ArrayList<T>();//一个页面的数据
	private int totalRecords;//查询到的总记录
	
	
	
	/**
	 * @return pageNo
	 */
	public int getPageNo() {
		return pageNo;
	}
	/**
	 * @param pageNo 要设置的 pageNo
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	/**
	 * @return pageSize
	 */
	public int getPageSize() {
		return pageSize;
	}
	/**
	 * @param pageSize 要设置的 pageSize
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	/**
	 * @return data
	 */
	public List<T> getData() {
		return data;
	}
	/**
	 * @param data 要设置的 data
	 */
	public void setData(List<T> data) {
		this.data = data;
	}
	/**
	 * @return totalRecords
	 */
	public int getTotalRecords() {
		return totalRecords;
	}
	/**
	 * @param totalRecords 要设置的 totalRecords
	 */
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	//返回总页数
	public int getTotalPage(){	
		return (this.totalRecords+this.pageSize-1)/this.pageSize;
	}
	
	//返回首页
	public int getFirstPage(){
		return 1;
	}
	
	//返回末页
	public int getLastPage(){
		if(this.totalRecords==0){
			return 1;
		}
		return this.getTotalPage();
	}
	
	//返回上一页
	public int getUpPage(){
		if(this.pageNo==1){
			return 1;			
		}
		return this.pageNo-1;
	}
	
	//返回下一页
	public int getDownPage(){
		if(this.pageNo==this.getLastPage()){
			return this.getLastPage();
		}
		return this.pageNo+1;
	}
	

}
