package bean;

import java.sql.Date;

public class ShipmentsInfo {
	private int order_id;//订单号
	private int p_id;
	private String p_name;//商品名称
	private String shipment_adress;//发货地址
	private String order_adress;//到货地址
	private String express;//快递名称
	private String Ship_state;//收货状态
	private String username;//用户
	private Date Shipments_date;//发货时间

	
	public ShipmentsInfo() {
		// TODO 自动生成的构造函数存根
	}





	/**
	 * @param order_id
	 * @param p_id
	 * @param p_name
	 * @param shipment_adress
	 * @param order_adress
	 * @param express
	 * @param ship_state
	 * @param username
	 * @param shipments_date
	 */
	public ShipmentsInfo(int order_id, int p_id, String p_name,
			String shipment_adress, String order_adress, String express,
			String ship_state, String username, Date shipments_date) {
		super();
		this.order_id = order_id;
		this.p_id = p_id;
		this.p_name = p_name;
		this.shipment_adress = shipment_adress;
		this.order_adress = order_adress;
		this.express = express;
		Ship_state = ship_state;
		this.username = username;
		Shipments_date = shipments_date;
	}





	/**
	 * @return order_id
	 */
	public int getOrder_id() {
		return order_id;
	}


	/**
	 * @param order_id 要设置的 order_id
	 */
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}


	/**
	 * @return p_name
	 */
	public String getP_name() {
		return p_name;
	}


	/**
	 * @param p_name 要设置的 p_name
	 */
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}


	/**
	 * @return shipment_adress
	 */
	public String getShipment_adress() {
		return shipment_adress;
	}


	/**
	 * @param shipment_adress 要设置的 shipment_adress
	 */
	public void setShipment_adress(String shipment_adress) {
		this.shipment_adress = shipment_adress;
	}


	/**
	 * @return order_adress
	 */
	public String getOrder_adress() {
		return order_adress;
	}


	/**
	 * @param order_adress 要设置的 order_adress
	 */
	public void setOrder_adress(String order_adress) {
		this.order_adress = order_adress;
	}


	/**
	 * @return express
	 */
	public String getExpress() {
		return express;
	}


	/**
	 * @param express 要设置的 express
	 */
	public void setExpress(String express) {
		this.express = express;
	}


	/**
	 * @return ship_state
	 */
	public String getShip_state() {
		return Ship_state;
	}


	/**
	 * @param ship_state 要设置的 ship_state
	 */
	public void setShip_state(String ship_state) {
		Ship_state = ship_state;
	}


	/**
	 * @return username
	 */
	public String getUsername() {
		return username;
	}


	/**
	 * @param username 要设置的 username
	 */
	public void setUsername(String username) {
		this.username = username;
	}


	/**
	 * @return shipments_date
	 */
	public Date getShipments_date() {
		return Shipments_date;
	}


	/**
	 * @param shipments_date 要设置的 shipments_date
	 */
	public void setShipments_date(Date shipments_date) {
		Shipments_date = shipments_date;
	}





	/**
	 * @return p_id
	 */
	public int getP_id() {
		return p_id;
	}





	/**
	 * @param p_id 要设置的 p_id
	 */
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	
	
	

	
	
}
