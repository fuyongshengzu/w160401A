package dto;

public class ProductDto {
	
	private String search_p_name;//查找商品名称
	private double search_down_p_price;//查找商品价格下限
	private double search_up_p_price;//查找商品价格上限
	private String search_p_type;//查找商品类型
	private String search_p_var;//查找商品品种
	/**
	 * @return search_p_name
	 */
	public String getSearch_p_name() {
		return search_p_name;
	}
	/**
	 * @param search_p_name 要设置的 search_p_name
	 */
	public void setSearch_p_name(String search_p_name) {
		this.search_p_name = search_p_name;
	}
	/**
	 * @return search_down_p_price
	 */
	public double getSearch_down_p_price() {
		return search_down_p_price;
	}
	/**
	 * @param search_down_p_price 要设置的 search_down_p_price
	 */
	public void setSearch_down_p_price(double search_down_p_price) {
		this.search_down_p_price = search_down_p_price;
	}
	/**
	 * @return search_up_p_price
	 */
	public double getSearch_up_p_price() {
		return search_up_p_price;
	}
	/**
	 * @param search_up_p_price 要设置的 search_up_p_price
	 */
	public void setSearch_up_p_price(double search_up_p_price) {
		this.search_up_p_price = search_up_p_price;
	}
	/**
	 * @return search_p_type
	 */
	public String getSearch_p_type() {
		return search_p_type;
	}
	/**
	 * @param search_p_type 要设置的 search_p_type
	 */
	public void setSearch_p_type(String search_p_type) {
		this.search_p_type = search_p_type;
	}
	/**
	 * @return search_p_var
	 */
	public String getSearch_p_var() {
		return search_p_var;
	}
	/**
	 * @param search_p_var 要设置的 search_p_var
	 */
	public void setSearch_p_var(String search_p_var) {
		this.search_p_var = search_p_var;
	}
	
	
	

}
