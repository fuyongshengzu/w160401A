package web.servlet1;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.OrderDao;

@WebServlet(name="updateOrdersByOrder_save",urlPatterns="/servlet/updateOrdersByOrder_save")
public class UpdateOrdersByOrder_save extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		int order_id=Integer.parseInt(req.getParameter("order_id"));
		String order_save=req.getParameter("order_save");
		
		OrderDao dao=new OrderDao();
		boolean flag=dao.updateOrderByOrder_save(order_id, order_save);
		if(flag){
			req.getRequestDispatcher("orderGetAll").forward(req,resp);
		}else{
			req.getRequestDispatcher("orderGetAll").forward(req,resp);
		}
	}
	
	

}
