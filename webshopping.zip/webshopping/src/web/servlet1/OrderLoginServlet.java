package web.servlet1;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Customer;
import dao.CustomerDao;

@WebServlet(name="orderLoginServlet",urlPatterns="/servlet/orderLogin")
public class OrderLoginServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String username=req.getParameter("txtUser");
		String pwd=req.getParameter("txtPwd");
		 HttpSession session=req.getSession();//得到session对象
		
		CustomerDao dao=new CustomerDao();
		Customer ct=dao.selectCustomer(username, pwd);	
		if(ct!=null&&ct.getUserName()!=null){			
			if(ct.getMold().equals("订单管理员")){
				session.setAttribute("orderCust", ct);
				resp.sendRedirect("../order/homepage.jsp");
			}
			else{
				session.removeAttribute("orderCust");
				resp.sendRedirect("../orderLogin.jsp");
			}	
			
		}else{				
			resp.sendRedirect("../orderLogin.jsp");			
		}
	}
	
	

}
