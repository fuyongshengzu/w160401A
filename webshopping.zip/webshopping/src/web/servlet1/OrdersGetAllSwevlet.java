package web.servlet1;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Orders;
import bean.PageBean;


import dao.OrderDao;

@WebServlet(name="ordersGetAllServlet",urlPatterns="/servlet/orderGetAll")
public class OrdersGetAllSwevlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// 定义初始默认值
		int pageNo = 1;
		int pageSize = 15;

		if (req.getParameter("pageNo") != null
				&& !"".equals(req.getParameter("pageNo"))) {
			pageNo = Integer.parseInt(req.getParameter("pageNo"));
		}
		if (req.getParameter("pageSize") != null
				&& !"".equals(req.getParameter("pageSize"))) {
			pageSize = Integer.parseInt(req.getParameter("pageSize"));
		}
		
		OrderDao dao=new OrderDao();
		//得到分页查询的结果
		ArrayList<Orders> list=dao.getPOrders(pageNo, pageSize);
		//将查询结果封装进页面对象
		PageBean<Orders> pb=new PageBean<Orders>();
		pb.setData(list);		
		pb.setPageNo(pageNo);
		pb.setPageSize(pageSize);
		pb.setTotalRecords(dao.getCount());
		
		req.setAttribute("pb", pb);
		req.getRequestDispatcher("../order/showOrders.jsp").forward(req, resp);
	}
	
	

}
