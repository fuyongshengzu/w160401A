package web.servlet1;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Orders;

import dao.OrderDao;

@WebServlet(name="ordersGetByOrder_idservlet",urlPatterns="/servlet/orderGetByOrder_id")
public class OrdersGetByOrder_idServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		int order_id=Integer.parseInt(req.getParameter("order_id"));
		
		OrderDao dao=new OrderDao();
		Orders od=dao.selectOrderByorder_id(order_id);
		req.setAttribute("od", od);
		req.getRequestDispatcher("../order/showOrdersByOrder_id.jsp").forward(req, resp);
	}
	
	

}
