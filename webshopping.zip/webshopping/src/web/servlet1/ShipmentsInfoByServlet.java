package web.servlet1;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.OrderDao;

import bean.Orders;
import bean.ShipmentsInfo;


@WebServlet(name="shipmentsInfoByServlet",urlPatterns="/servlet/shipmentsInfoBy")
public class ShipmentsInfoByServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		int order_id=Integer.parseInt(req.getParameter("order_id"));
		OrderDao dao=new OrderDao();
		Orders od=dao.selectOrderByorder_id(order_id);
		
		String express=req.getParameter("express");
		ShipmentsInfo spt=new ShipmentsInfo();
		spt.setOrder_id(od.getOrder_id());
		spt.setP_id(od.getP_id());
		spt.setOrder_adress(od.getOrder_adres());
		spt.setUsername(od.getUsername());
		spt.setExpress(express);
		
		ShipmentsInfo sp=dao.selectShipmentsInfoByorder_id(spt.getOrder_id());
		if(sp.getUsername()==null){
			boolean flag=dao.insertShipmentsInfo(spt);
			if(flag){
				req.getRequestDispatcher("orderGetAll").forward(req,resp);
			}
			else{
				req.setAttribute("spt", spt);
				req.getRequestDispatcher("../order/shipmentsInfo.jsp").forward(req,resp);
			}
		}else{
			req.getRequestDispatcher("orderGetAll").forward(req,resp);
		}
		
		
	}
	
	

}
