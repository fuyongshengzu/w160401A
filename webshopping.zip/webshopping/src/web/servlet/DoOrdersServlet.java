package web.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Car;
import bean.Customer;
import bean.Orders;
import dao.CarDao;
import dao.CustomerDao;

@WebServlet(name="doOrdersServlet",urlPatterns="/servlet/doOrders")
public class DoOrdersServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String username=req.getParameter("txtUsername");
		int p_id = Integer.parseInt(req.getParameter("txtP_id"));
		System.out.println(username);
		System.out.println(p_id);
		//查询购物车里的信息
		CarDao cdao = new CarDao();
		Car car=cdao.selectCarByP_id(p_id, username);
		//查询用户信息
		CustomerDao dao=new CustomerDao();
		Customer ct=dao.selectCustomerByUserName(username);

		Orders od=new Orders();
		od.setP_id(car.getP_id());
		od.setP_name(car.getP_name());
		od.setP_price(car.getP_price());
		od.setP_quantity(car.getOrder_count());
		od.setOrder_sum(car.getOrder_sum());
		od.setOrder_user(ct.getTrueName());
		od.setOrder_adres(ct.getAddress());
		od.setUsername(ct.getUserName());
		od.setOreder_phone(ct.getPhone());
		
		
		ArrayList<Orders> list=new ArrayList<Orders>();
		list.add(od);
		
		
		HttpSession session=req.getSession();
		session.setAttribute("od", od);
		session.setAttribute("odList", list);
		resp.sendRedirect("../customer/orderinfo.jsp");
		//req.getRequestDispatcher("../customer/orderinfo.jsp").forward(req,resp);
	}
	
	

}
