package web.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CarDao;

import bean.Car;


@WebServlet(name="showCarServlet",urlPatterns="/servlet/showCar")
public class ShowCarServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String username=req.getParameter("txtUsername");
		CarDao cdao = new CarDao();
		ArrayList<Car> list = cdao.selectAll(username);
		HttpSession session=req.getSession();
		
		session.setAttribute("count", list.size());
		session.setAttribute("carList", list);
		System.out.println(list.size());
		resp.sendRedirect("../customer/car.jsp");
	}
	
	

}
