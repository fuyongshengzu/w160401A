package web.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Car;
import dao.CarDao;

@WebServlet(name="updateCarServlet",urlPatterns="/servlet/updateCar")
public class UpdateCarServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String username=req.getParameter("txtUsername");
		int p_id = Integer.parseInt(req.getParameter("txtP_id"));
		int Order_count=Integer.parseInt(req.getParameter("txtNum"));

		CarDao cdao = new CarDao();
		Car car = cdao.selectCarByP_id(p_id,username);
		car.setOrder_count(Order_count);
		car.setOrder_sum(Order_count* car.getP_price());
		car.setUsername(username);
		
		boolean flag=cdao.updateCarByP_id(car);
		if(flag){
			ArrayList<Car> list = cdao.selectAll(username);
			req.setAttribute("carList", list);
			req.getRequestDispatcher("../customer/car.jsp").forward(req,resp);
		}
		else{
			req.getRequestDispatcher("../customer/car.jsp").forward(req,resp);
		}
		
	}
	
	
	
}
