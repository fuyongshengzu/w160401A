package web.servlet;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PageBean;
import bean.Product;

import dao.CustomerDao;

@WebServlet(name="productByP_typeServlet",urlPatterns="/servlet/productByP_type")
public class ProductByP_typeServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String p_type=req.getParameter("p_type");
		//定义初始默认值
		int pageNo=1;
		int pageSize=10;
		
		if(req.getParameter("pageNo")!=null && !"".equals(req.getParameter("pageNo"))){
			pageNo=Integer.parseInt(req.getParameter("pageNo"));
		}
		if(req.getParameter("pageSize")!=null && !"".equals(req.getParameter("pageSize"))){
			pageSize=Integer.parseInt(req.getParameter("pageSize"));
		}
		
		CustomerDao dao=new CustomerDao();
		//得到分页查询的结果
		List<Product> list=dao.getProductByP_type(p_type, pageNo, pageSize);
		
		//将查询结果封装进页面对象
		PageBean<Product> pb=new PageBean<Product>();
		pb.setData(list);
		pb.setPageNo(pageNo);
		pb.setPageSize(pageSize);
		pb.setTotalRecords(dao.getCountByP_type(p_type));
		
		req.setAttribute("p_type", p_type);
		req.setAttribute("pb", pb);
		req.getRequestDispatcher("../customer/reder1.jsp").forward(req, resp);
			
	}
	
	

}
