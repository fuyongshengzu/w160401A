package web.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PageBean;
import bean.Product;
import dao.CustomerDao;
import dto.ProductDto;

@WebServlet(name="advance1Select",urlPatterns="/servlet/advance1Select")
public class Advance1SelectServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String search_p_name=req.getParameter("ssearch_p_name");
		String search_p_type=req.getParameter("ssearch_p_type");
		String search_p_var=req.getParameter("ssearch_p_var");
		double search_down_p_price=0;
		double search_up_p_price=10000;
		if(req.getParameter("search_down_p_price")!=null&&!"".equals(req.getParameter("search_down_p_price"))){
			search_down_p_price=Double.parseDouble(req.getParameter("search_down_p_price"));		
		}
		if(req.getParameter("search_up_p_price")!=null&&!"".equals(req.getParameter("search_up_p_price"))){
			search_down_p_price=Double.parseDouble(req.getParameter("search_up_p_price"));		
		}
		
		ProductDto dto=new ProductDto();
		dto.setSearch_p_name(search_p_name);
		dto.setSearch_p_type(search_p_type);
		dto.setSearch_p_var(search_p_var);
		dto.setSearch_down_p_price(search_down_p_price);
		dto.setSearch_up_p_price(search_up_p_price);

		// 定义初始默认值
		int pageNo = 1;
		int pageSize = 10;

		if (req.getParameter("pageNo") != null
				&& !"".equals(req.getParameter("pageNo"))) {
			pageNo = Integer.parseInt(req.getParameter("pageNo"));
		}
		if (req.getParameter("pageSize") != null
				&& !"".equals(req.getParameter("pageSize"))) {
			pageSize = Integer.parseInt(req.getParameter("pageSize"));
		}

		CustomerDao dao = new CustomerDao();
		ArrayList<Product> list = dao.getAdvanceSelect(dto, pageNo, pageSize);
		// 将查询结果封装进页面对象
		PageBean<Product> pb = new PageBean<Product>();
		pb.setData(list);
		pb.setPageNo(pageNo);
		pb.setPageSize(pageSize);
		pb.setTotalRecords(dao.getCountAdvanceSelect(dto));

		req.setAttribute("dto", dto);
		req.setAttribute("pb", pb);
		req.getRequestDispatcher("../customer/reder2.jsp").forward(req, resp);
	}

	
	
}
