package web.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Assess;
import bean.PageBean;
import bean.Product;
import dao.CustomerDao;

@WebServlet(name="doCarServlet",urlPatterns="/servlet/doCar")
public class DoCarServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		int p_id = Integer.parseInt(req.getParameter("txtP_id"));
		// 定义初始默认值
		int pageNo = 1;
		int pageSize = 10;

		if (req.getParameter("pageNo") != null
				&& !"".equals(req.getParameter("pageNo"))) {
			pageNo = Integer.parseInt(req.getParameter("pageNo"));
		}
		if (req.getParameter("pageSize") != null
				&& !"".equals(req.getParameter("pageSize"))) {
			pageSize = Integer.parseInt(req.getParameter("pageSize"));
		}
		CustomerDao dao = new CustomerDao();
		Product pd = dao.getProductByP_id(p_id);
		ArrayList<Assess> list = dao.getAssessByP_id(p_id, pageNo, pageSize);
		// 将查询结果封装进页面对象
		PageBean<Assess> pb = new PageBean<Assess>();
		pb.setData(list);
		pb.setPageNo(pageNo);
		pb.setPageSize(pageSize);
		pb.setTotalRecords(dao.getCountAssess(p_id));

		req.setAttribute("p_id", p_id);
		req.setAttribute("pd", pd);
		req.setAttribute("pb", pb);
		req.setAttribute("assessList", list);
		req.getRequestDispatcher("../customer/showCar.jsp").forward(req, resp);
		
	}
	
	

}
