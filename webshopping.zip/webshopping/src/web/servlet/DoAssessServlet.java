package web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CustomerDao;

import bean.Assess;

@WebServlet(name="doAssessServlet",urlPatterns="/servlet/doAssess")
public class DoAssessServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		int p_id=Integer.parseInt(req.getParameter("p_id"));
		String username=req.getParameter("username");
		String wares_asses=req.getParameter("textarea");
		
		Assess as=new Assess();
		as.setP_id(p_id);
		as.setUserName(username);
		as.setWares_asses(wares_asses);
		
		CustomerDao dao=new CustomerDao();
		//向商品评价表添加数据
		boolean flag=dao.insertAssess(as);
		if(flag){
			req.getRequestDispatcher("shipmentByUsername1").forward(req, resp);
		}else{
			req.getRequestDispatcher("../customer/assess.jsp").forward(req, resp);
		}
		
	}
	
	

}
