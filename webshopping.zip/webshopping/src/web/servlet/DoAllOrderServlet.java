package web.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CustomerDao;

import bean.Car;
import bean.Customer;
import bean.Orders;

@WebServlet(name="doAllOrderServlet",urlPatterns="/servlet/doAllOrder")
public class DoAllOrderServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		HttpSession session=req.getSession();
		ArrayList<Car> list=(ArrayList<Car>)session.getAttribute("carList");
		
		System.out.println(list.size());
		
		ArrayList<Orders> list1=new ArrayList<Orders>();
		
		for(int i=0;i<list.size();i++){
			CustomerDao dao=new CustomerDao();
			Customer ct=dao.selectCustomerByUserName(list.get(i).getUsername());
			Orders od=new Orders();			
			od.setP_id(list.get(i).getP_id());
			od.setP_name(list.get(i).getP_name());
			od.setP_price(list.get(i).getP_price());
			od.setP_quantity(list.get(i).getOrder_count());
			od.setOrder_sum(list.get(i).getOrder_sum());			
			od.setOrder_user(ct.getTrueName());
			od.setOrder_adres(ct.getAddress());
			od.setUsername(ct.getUserName());
			od.setOreder_phone(ct.getPhone());
			list1.add(od);
		}
		
		Orders od1=list1.get(0);		
		session.setAttribute("od", od1);
		session.setAttribute("odList", list1);
		System.out.println(list1.size());
		resp.sendRedirect("../customer/orderinfo.jsp");
		
		
	}
	
	

}
