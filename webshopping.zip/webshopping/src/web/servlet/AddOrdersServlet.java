package web.servlet;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CarDao;
import dao.CustomerDao;

import bean.Car;
import bean.Customer;
import bean.Orders;

@WebServlet(name="addOrdersServlet",urlPatterns="/servlet/addOrders")
public class AddOrdersServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		
		String order_user=req.getParameter("txtOrder_user");
		String order_phone=req.getParameter("txtOrder_phone");
		String order_adres=req.getParameter("txtOrder_adres");
		
		HttpSession session=req.getSession();
		ArrayList<Orders> list=(ArrayList<Orders>)session.getAttribute("odList");
		boolean flag1=false;
		boolean flag2=false;
		boolean flag3=false;
		
		for(int i=0;i<list.size();i++){
			Orders od=list.get(i);
			od.setOrder_adres(order_adres);
			od.setOrder_user(order_user);
			od.setOreder_phone(order_phone);
			CustomerDao dao=new CustomerDao();
			flag1=dao.insertOrders(od);
			if(!flag1){
				break;				
			}
			CarDao cdao=new CarDao();
			flag2=cdao.deleteByP_id(od.getP_id(), od.getUsername());
			// 查询购物车所有信息
			ArrayList<Car> list1 = cdao.selectAll(od.getUsername());
			session.setAttribute("count", list.size());
			if(!flag2){
				break;
			}
			flag3=dao.updateProductByP_quantity(od.getP_id(), od.getP_quantity());
			if(!flag3){
				break;
			}
			
		}
		if(flag1&flag2&flag3){			
			req.getRequestDispatcher("orderByUsername").forward(req,resp);	
		}
		else{
			req.getRequestDispatcher("../customer/car.jsp").forward(req,resp);
		}
		
		
		
		
	}
	
	

}
