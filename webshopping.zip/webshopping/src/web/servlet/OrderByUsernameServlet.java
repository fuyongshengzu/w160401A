package web.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Customer;
import bean.Orders;
import bean.PageBean;
import bean.Product;

import dao.CustomerDao;


@WebServlet(name="orderByUsernameServlet",urlPatterns="/servlet/orderByUsername")
public class OrderByUsernameServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		HttpSession session = req.getSession();
		Customer ct = (Customer) session.getAttribute("customer");

		// 定义初始默认值
		int pageNo = 1;
		int pageSize = 10;

		if (req.getParameter("pageNo") != null
				&& !"".equals(req.getParameter("pageNo"))) {
			pageNo = Integer.parseInt(req.getParameter("pageNo"));
		}
		if (req.getParameter("pageSize") != null
				&& !"".equals(req.getParameter("pageSize"))) {
			pageSize = Integer.parseInt(req.getParameter("pageSize"));
		}

		CustomerDao dao = new CustomerDao();
		ArrayList<Orders> list = dao.selectOrdersByUsername(ct.getUserName(), pageNo, pageSize);

		// 将查询结果封装进页面对象
		PageBean<Orders> pb = new PageBean<Orders>();
		pb.setData(list);
		pb.setPageNo(pageNo);
		pb.setPageSize(pageSize);
		pb.setTotalRecords(dao.getCountOrders(ct.getUserName()));

		req.setAttribute("orderList", list);
		req.setAttribute("pb", pb);
		req.getRequestDispatcher("../customer/orderByUsername.jsp").forward(req, resp);
	}
	
	

}
