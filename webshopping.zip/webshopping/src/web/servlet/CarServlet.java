package web.servlet;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Car;
import bean.Product;

import dao.CarDao;
import dao.CustomerDao;

@WebServlet(name="carservlet",urlPatterns="/servlet/car")
public class CarServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String username=req.getParameter("txtUsername");
		int p_id = Integer.parseInt(req.getParameter("txtP_id"));
		// 判断当前用户是否登录,如果登录，则向购物车添加数据,否则，返回登录界面

		CarDao cdao = new CarDao();
		Car car = cdao.selectCarByP_id(p_id,username);
		// req.setAttribute("ccar", car);
		
		HttpSession session=req.getSession();

		// 判断购物车是否存在,如果不存在，则添加数据，如果存在，则修改数量和总金额,数量在原有的基础上添加1
		if (car.getP_name() != null && !"".equals(car.getP_name())) {
			int oldCount = car.getOrder_count();
			car.setOrder_count(oldCount + 1);
			car.setOrder_sum(car.getOrder_count() * car.getP_price());
			car.setUsername(username);

			boolean flag2 = cdao.updateCarByP_id(car);
			if (flag2) {
				// 查询购物车所有信息
				ArrayList<Car> list = cdao.selectAll(username);
				session.setAttribute("count", list.size());
				session.setAttribute("carList", list);
				resp.sendRedirect("../customer/car.jsp");
			} else {
				ArrayList<Car> list = cdao.selectAll(username);
				session.setAttribute("count", list.size());
				session.setAttribute("carList", list);
				resp.sendRedirect("../customer/car.jsp");
			}

		}

		else {
			CustomerDao dao = new CustomerDao();
			Product pd = dao.getProductByP_id(p_id);
			car.setP_id(pd.getP_id());
			car.setP_name(pd.getP_name());
			car.setP_price(pd.getP_price());
			car.setOrder_count(1);
			car.setUsername(username);
			boolean flag1 = cdao.insertCar(car);
			if (flag1) {
				// 查询购物车所有信息
				ArrayList<Car> list = cdao.selectAll(username);
				session.setAttribute("count", list.size());
				session.setAttribute("carList", list);
				resp.sendRedirect("../customer/car.jsp");
			} else {
				ArrayList<Car> list = cdao.selectAll(username);
				session.setAttribute("count", list.size());
				session.setAttribute("carList", list);
				resp.sendRedirect("../customer/car.jsp");
			}
		}

	}

}
