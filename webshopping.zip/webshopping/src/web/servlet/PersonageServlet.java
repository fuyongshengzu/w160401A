package web.servlet;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CustomerDao;

import bean.Customer;


@WebServlet(name="personageServlet",urlPatterns="/servlet/personage")
public class PersonageServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		CustomerDao dao=new CustomerDao();
		
		String username=req.getParameter("txtUserName");
		String name=req.getParameter("txtName");
		String sex=req.getParameter("sex");
		String phone=req.getParameter("txtPhone");
		String email=req.getParameter("txtEmail");
		String address=req.getParameter("txtAddress");
		HttpSession session=req.getSession();//得到session对象
		
		Customer cust=(Customer)session.getAttribute("orderCust");
		cust.setUserName(username);
		cust.setAddress(address);
		cust.setTrueName(name);
		cust.setEmail(email);
		cust.setPhone(phone);
		cust.setSex(sex);
		boolean flag=dao.updateCustomer(cust);
		if(flag){
			session.setAttribute("orderCust", cust);
			req.getRequestDispatcher("../order/orderpersonage.jsp").forward(req, resp);
		}else{
			req.getRequestDispatcher("../order/orderpersonage.jsp").forward(req, resp);
		}
		
	}
	
	

}
