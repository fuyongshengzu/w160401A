package web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Assess;
import bean.Customer;
import bean.Product;

import dao.CustomerDao;

@WebServlet(name="assessServlet",urlPatterns="/servlet/assess")
public class AssessServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		int p_id=Integer.parseInt(req.getParameter("p_id"));
		String username=req.getParameter("username");
		int order_id=Integer.parseInt(req.getParameter("order_id"));
		
		Assess as=new Assess();
		as.setP_id(p_id);
		as.setUserName(username);
		CustomerDao dao=new CustomerDao();
		//修改发货信息表的发货状态为“已发货”
		boolean flag=dao.updateShipmentsInatefoSt(order_id);
		if(flag){
			req.setAttribute("assess", as);
			req.getRequestDispatcher("../customer/assess.jsp").forward(req, resp);
		}else{
			req.getRequestDispatcher("../customer/shipmentByUsername.jsp").forward(req, resp);
		}
		
		
		
	}
	
	

}
