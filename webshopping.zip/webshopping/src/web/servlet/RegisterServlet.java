package web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Customer;

import dao.CustomerDao;


@WebServlet(name="registerServlet",urlPatterns="/servlet/refister")
public class RegisterServlet extends HttpServlet{

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}

	/* （非 Javadoc）
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String username=req.getParameter("txtUserName");
		String pwd=req.getParameter("txtPwd");
		String name=req.getParameter("txtName");
		String sex=req.getParameter("sex");
		String phone=req.getParameter("txtPhone");
		String email=req.getParameter("txtEmail");
		String address=req.getParameter("txtAddress");
		
		Customer ct=new Customer();
		ct.setUserName(username);
		ct.setPassword(pwd);
		ct.setTrueName(name);
		ct.setSex(sex);
		ct.setPhone(phone);
		ct.setEmail(email);
		ct.setAddress(address);
		
		HttpSession session=req.getSession();//得到session对象
		CustomerDao dao=new CustomerDao();
		boolean flag=dao.insertCustomer(ct);
		if(flag){
			session.setAttribute("customer", ct);
			resp.sendRedirect("../customer/index.jsp");
		}else{
			resp.sendRedirect("../customer/register.jsp");
		}
		
		
		
		
	}
	
	

}
